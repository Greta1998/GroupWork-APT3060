package com.example.groupwork;
import android.os.Bundle;
import com.example.groupwork.R;

import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;
import android.widget.Toast;

import android.content.Context;

public class ReportActivity extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference ordersRef;
    private TextView reportView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        database = FirebaseDatabase.getInstance();
        ordersRef = database.getReference("branches");

        reportView = findViewById(R.id.reportView);
        generateReports();
    }

    private void generateReports() {
        ordersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                StringBuilder report = new StringBuilder();
                double totalAmount = 0.0;

                for (DataSnapshot branchSnapshot : dataSnapshot.getChildren()) {
                    String branchName = branchSnapshot.child("name").getValue(String.class);
                    report.append("Branch: ").append(branchName).append("\n");

                    double branchTotal = 0.0;
                    for (DataSnapshot orderSnapshot : branchSnapshot.child("orders").getChildren()) {
                        double orderAmount = orderSnapshot.child("totalAmount").getValue(Double.class);
                        branchTotal += orderAmount;
                    }
                    report.append("Total Sales: ").append(branchTotal).append("\n\n");
                    totalAmount += branchTotal;
                }

                report.append("Total Sales for All Branches: ").append(totalAmount).append("\n");
                reportView.setText(report.toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ReportActivity.this, "Failed to load report.",
                        Toast.LENGTH_SHORT).show();
            }


        });
    }
}
