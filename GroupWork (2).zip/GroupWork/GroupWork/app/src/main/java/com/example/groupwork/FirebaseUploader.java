package com.example.groupwork;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.content.Context;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;

public class FirebaseUploader {

    private DatabaseReference mDatabase;

    public FirebaseUploader() {
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    public void uploadJsonData(Context context) {
        String jsonData = JsonUtils.readJsonFile(context, R.raw.data);
        try {
            JSONObject jsonObject = new JSONObject(jsonData);
            mDatabase.setValue(jsonObject.toString());
        } catch (JSONException e) {
            Log.e("FirebaseUploader", "Error parsing JSON data", e);
        }
    }
}
