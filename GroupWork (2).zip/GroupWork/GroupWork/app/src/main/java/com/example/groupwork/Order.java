package com.example.groupwork;


public class Order {
    private String customerId;
    private String drink;
    private int quantity;

    public Order() {
        // Default constructor required for Firebase
    }

    public Order(String customerId, String drink, int quantity) {
        this.customerId = customerId;
        this.drink = drink;
        this.quantity = quantity;
    }



    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getDrink() {
        return drink;
    }

    public void setDrink(String drink) {
        this.drink = drink;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
