package com.example.groupwork;

import static com.example.groupwork.R.id.main;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminActivity extends AppCompatActivity {

    private Spinner branchSpinner;
    private EditText stockInput;
    private Button addStockButton;
    private Button orderButton;
    private Button receiptButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        branchSpinner = findViewById(R.id.branchSpinner);
        stockInput = findViewById(R.id.stockInput);
        addStockButton = findViewById(R.id.addStockButton);
        orderButton = findViewById(R.id.orderButton);
        receiptButton = findViewById(R.id.receiptButton);

        addStockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String branch = branchSpinner.getSelectedItem().toString();
                String stock = stockInput.getText().toString();
                Toast.makeText(AdminActivity.this, "Added " + stock + " stock to " + branch, Toast.LENGTH_SHORT).show();
            }
        });

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String branch = branchSpinner.getSelectedItem().toString();
                Toast.makeText(AdminActivity.this, "Order placed in branch: " + branch, Toast.LENGTH_SHORT).show();
            }
        });

        receiptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AdminActivity.this, "Viewing receipt", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
