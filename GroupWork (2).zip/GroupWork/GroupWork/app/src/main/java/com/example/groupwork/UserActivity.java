package com.example.groupwork;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserActivity extends AppCompatActivity {

    private Spinner branchSpinner = findViewById(R.id .main);
    private Button orderButton;
    private Button receiptButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        orderButton = findViewById(R.id.orderButton);
        receiptButton = findViewById(R.id.receiptButton);

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String branch = branchSpinner.getSelectedItem().toString();
                Toast.makeText(UserActivity.this, "Order placed in branch: " + branch, Toast.LENGTH_SHORT).show();
            }
        });

        receiptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(UserActivity.this, "Viewing receipt", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
