package com.example.groupwork;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class StockMonitoringService extends Service {
    private FirebaseDatabase database;
    private DatabaseReference stockRef;

    @Override
    public void onCreate() {
        super.onCreate();
        database = FirebaseDatabase.getInstance();
        stockRef = database.getReference("branches/branch1/stock");
        monitorStockLevels();
    }

    private void monitorStockLevels() {
        stockRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot stockSnapshot : dataSnapshot.getChildren()) {
                    int quantity = stockSnapshot.getValue(Integer.class);
                    if (quantity < 10) {
                        sendLowStockAlert(stockSnapshot.getKey());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("StockMonitoringService", "Failed to monitor stock levels.");
            }
        });
    }

    private void sendLowStockAlert(String drink) {
        DatabaseReference alertRef = database.getReference("alerts/branch1/lowStock");
        alertRef.child(drink).setValue(true);

        String message = "Stocks are low, Kindly restock";
        sendSMS("+254727391082", message);
        sendSMS("+254722160552", message);
        sendSMS("+254111227311", message);
        sendEmail("tangaroy.rt@gmail.com", "Low Stock Alert", message);
    }

    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    private void sendEmail(final String to, final String subject, final String message) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String username = "Aptgroup3@gmail.com";
                    final String password = "GretaTangaEddy+1";

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", "smtp.gmail.com");
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(username, password);
                        }
                    });

                    Message mimeMessage = new MimeMessage(session);
                    mimeMessage.setFrom(new InternetAddress(username));
                    mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
                    mimeMessage.setSubject(subject);
                    mimeMessage.setText(message);

                    Transport.send(mimeMessage);
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
