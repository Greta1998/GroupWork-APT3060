package com.example.groupwork;
import com.example.groupwork.Order;// Replace with the actual package name
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.util.Log;
import android.telephony.data.*;
import android.telephony.SmsMessage;
import android.widget.EditText;
import android.widget.Button;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
//import androidx.activity.R;
import com.example.groupwork.R;
import android.widget.Toast;


public class OrderActivity extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference ordersRef;
    private EditText drinkInput, quantityInput;
    private Button orderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        database = FirebaseDatabase.getInstance();
        ordersRef = database.getReference("branches/branch1/orders");

        drinkInput = findViewById(R.id.drinkInput);
        quantityInput = findViewById(R.id.quantityInput);
        orderButton = findViewById(R.id.orderButton);

        orderButton.setOnClickListener(view -> placeOrder());
    }

    private void placeOrder() {
        String drink = drinkInput.getText().toString();
        int quantity = Integer.parseInt(quantityInput.getText().toString());

        String orderId = ordersRef.push().getKey();
        Order order = new Order(FirebaseAuth.getInstance().getCurrentUser().getUid(), drink, quantity);
        ordersRef.child(orderId).setValue(order);

        Toast.makeText(OrderActivity.this, "Thank you dear customer for placing your order with us!",
                Toast.LENGTH_LONG).show();
    }
}
