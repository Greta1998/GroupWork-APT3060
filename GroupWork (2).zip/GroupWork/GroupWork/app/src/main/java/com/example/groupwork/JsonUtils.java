package com.example.groupwork;
import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class JsonUtils {

    public static String readJsonFile(Context context, int resourceId) {
        InputStream inputStream = context.getResources().openRawResource(resourceId);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        try {
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            Log.e("JsonUtils", "Error reading JSON file", e);
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                Log.e("JsonUtils", "Error closing BufferedReader", e);
            }
        }
        return stringBuilder.toString();
    }
}
